"""거리 구간화 헬퍼"""

def classify_zone(depth: float) -> str:
    """depth를 거리 구간으로 분류. 값이 작을수록 가까운 객체."""
    if depth <= 0.75:         # 수정됨: 기존 0.85 -> 0.5 (초근접 위험, 빨강)
        return "danger"
    elif depth <= 0.90:      # 수정됨: 기존 0.93 -> 0.85 (경고, 노랑)
        return "warning"
    return "safe"            # 0.85 초과 (안전, 파랑)